# Ravix branding

App name: Ravix
Tagline: Stream Beyond
Android package: com.ravix.stream
URL scheme: ravix
Brand direction: dark/black base with electric purple and cyan accents.
Logo: stylized R with play symbol.

This is a rebrand/customization of the supplied Vega source. Retain the upstream Apache-2.0 LICENSE and applicable notices.
